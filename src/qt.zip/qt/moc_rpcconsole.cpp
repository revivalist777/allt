/****************************************************************************
** Meta object code from reading C++ file 'rpcconsole.h'
**
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "qt/rpcconsole.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rpcconsole.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_RPCConsole_t {
    QByteArrayData data[65];
    char stringdata0[884];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RPCConsole_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RPCConsole_t qt_meta_stringdata_RPCConsole = {
    {
QT_MOC_LITERAL(0, 0, 10), // "RPCConsole"
QT_MOC_LITERAL(1, 11, 12), // "stopExecutor"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 10), // "cmdRequest"
QT_MOC_LITERAL(4, 36, 7), // "command"
QT_MOC_LITERAL(5, 44, 13), // "handleRestart"
QT_MOC_LITERAL(6, 58, 4), // "args"
QT_MOC_LITERAL(7, 63, 25), // "on_lineEdit_returnPressed"
QT_MOC_LITERAL(8, 89, 27), // "on_tabWidget_currentChanged"
QT_MOC_LITERAL(9, 117, 5), // "index"
QT_MOC_LITERAL(10, 123, 33), // "on_openDebugLogfileButton_cli..."
QT_MOC_LITERAL(11, 157, 29), // "on_sldGraphRange_valueChanged"
QT_MOC_LITERAL(12, 187, 5), // "value"
QT_MOC_LITERAL(13, 193, 18), // "updateTrafficStats"
QT_MOC_LITERAL(14, 212, 12), // "totalBytesIn"
QT_MOC_LITERAL(15, 225, 13), // "totalBytesOut"
QT_MOC_LITERAL(16, 239, 11), // "resizeEvent"
QT_MOC_LITERAL(17, 251, 13), // "QResizeEvent*"
QT_MOC_LITERAL(18, 265, 5), // "event"
QT_MOC_LITERAL(19, 271, 9), // "showEvent"
QT_MOC_LITERAL(20, 281, 11), // "QShowEvent*"
QT_MOC_LITERAL(21, 293, 9), // "hideEvent"
QT_MOC_LITERAL(22, 303, 11), // "QHideEvent*"
QT_MOC_LITERAL(23, 315, 25), // "showPeersTableContextMenu"
QT_MOC_LITERAL(24, 341, 5), // "point"
QT_MOC_LITERAL(25, 347, 23), // "showBanTableContextMenu"
QT_MOC_LITERAL(26, 371, 28), // "showOrHideBanTableIfRequired"
QT_MOC_LITERAL(27, 400, 17), // "clearSelectedNode"
QT_MOC_LITERAL(28, 418, 5), // "clear"
QT_MOC_LITERAL(29, 424, 13), // "walletSalvage"
QT_MOC_LITERAL(30, 438, 12), // "walletRescan"
QT_MOC_LITERAL(31, 451, 14), // "walletZaptxes1"
QT_MOC_LITERAL(32, 466, 14), // "walletZaptxes2"
QT_MOC_LITERAL(33, 481, 13), // "walletUpgrade"
QT_MOC_LITERAL(34, 495, 13), // "walletReindex"
QT_MOC_LITERAL(35, 509, 12), // "walletResync"
QT_MOC_LITERAL(36, 522, 6), // "reject"
QT_MOC_LITERAL(37, 529, 7), // "message"
QT_MOC_LITERAL(38, 537, 8), // "category"
QT_MOC_LITERAL(39, 546, 4), // "html"
QT_MOC_LITERAL(40, 551, 17), // "setNumConnections"
QT_MOC_LITERAL(41, 569, 5), // "count"
QT_MOC_LITERAL(42, 575, 12), // "setNumBlocks"
QT_MOC_LITERAL(43, 588, 18), // "setMasternodeCount"
QT_MOC_LITERAL(44, 607, 14), // "strMasternodes"
QT_MOC_LITERAL(45, 622, 13), // "browseHistory"
QT_MOC_LITERAL(46, 636, 6), // "offset"
QT_MOC_LITERAL(47, 643, 11), // "scrollToEnd"
QT_MOC_LITERAL(48, 655, 8), // "showInfo"
QT_MOC_LITERAL(49, 664, 11), // "showConsole"
QT_MOC_LITERAL(50, 676, 11), // "showNetwork"
QT_MOC_LITERAL(51, 688, 9), // "showPeers"
QT_MOC_LITERAL(52, 698, 10), // "showRepair"
QT_MOC_LITERAL(53, 709, 14), // "showConfEditor"
QT_MOC_LITERAL(54, 724, 16), // "showMNConfEditor"
QT_MOC_LITERAL(55, 741, 12), // "peerSelected"
QT_MOC_LITERAL(56, 754, 14), // "QItemSelection"
QT_MOC_LITERAL(57, 769, 8), // "selected"
QT_MOC_LITERAL(58, 778, 10), // "deselected"
QT_MOC_LITERAL(59, 789, 17), // "peerLayoutChanged"
QT_MOC_LITERAL(60, 807, 22), // "disconnectSelectedNode"
QT_MOC_LITERAL(61, 830, 15), // "banSelectedNode"
QT_MOC_LITERAL(62, 846, 7), // "bantime"
QT_MOC_LITERAL(63, 854, 17), // "unbanSelectedNode"
QT_MOC_LITERAL(64, 872, 11) // "showBackups"

    },
    "RPCConsole\0stopExecutor\0\0cmdRequest\0"
    "command\0handleRestart\0args\0"
    "on_lineEdit_returnPressed\0"
    "on_tabWidget_currentChanged\0index\0"
    "on_openDebugLogfileButton_clicked\0"
    "on_sldGraphRange_valueChanged\0value\0"
    "updateTrafficStats\0totalBytesIn\0"
    "totalBytesOut\0resizeEvent\0QResizeEvent*\0"
    "event\0showEvent\0QShowEvent*\0hideEvent\0"
    "QHideEvent*\0showPeersTableContextMenu\0"
    "point\0showBanTableContextMenu\0"
    "showOrHideBanTableIfRequired\0"
    "clearSelectedNode\0clear\0walletSalvage\0"
    "walletRescan\0walletZaptxes1\0walletZaptxes2\0"
    "walletUpgrade\0walletReindex\0walletResync\0"
    "reject\0message\0category\0html\0"
    "setNumConnections\0count\0setNumBlocks\0"
    "setMasternodeCount\0strMasternodes\0"
    "browseHistory\0offset\0scrollToEnd\0"
    "showInfo\0showConsole\0showNetwork\0"
    "showPeers\0showRepair\0showConfEditor\0"
    "showMNConfEditor\0peerSelected\0"
    "QItemSelection\0selected\0deselected\0"
    "peerLayoutChanged\0disconnectSelectedNode\0"
    "banSelectedNode\0bantime\0unbanSelectedNode\0"
    "showBackups"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RPCConsole[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      44,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  234,    2, 0x06 /* Public */,
       3,    1,  235,    2, 0x06 /* Public */,
       5,    1,  238,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    0,  241,    2, 0x08 /* Private */,
       8,    1,  242,    2, 0x08 /* Private */,
      10,    0,  245,    2, 0x08 /* Private */,
      11,    1,  246,    2, 0x08 /* Private */,
      13,    2,  249,    2, 0x08 /* Private */,
      16,    1,  254,    2, 0x08 /* Private */,
      19,    1,  257,    2, 0x08 /* Private */,
      21,    1,  260,    2, 0x08 /* Private */,
      23,    1,  263,    2, 0x08 /* Private */,
      25,    1,  266,    2, 0x08 /* Private */,
      26,    0,  269,    2, 0x08 /* Private */,
      27,    0,  270,    2, 0x08 /* Private */,
      28,    0,  271,    2, 0x0a /* Public */,
      29,    0,  272,    2, 0x0a /* Public */,
      30,    0,  273,    2, 0x0a /* Public */,
      31,    0,  274,    2, 0x0a /* Public */,
      32,    0,  275,    2, 0x0a /* Public */,
      33,    0,  276,    2, 0x0a /* Public */,
      34,    0,  277,    2, 0x0a /* Public */,
      35,    0,  278,    2, 0x0a /* Public */,
      36,    0,  279,    2, 0x0a /* Public */,
      37,    3,  280,    2, 0x0a /* Public */,
      37,    2,  287,    2, 0x2a /* Public | MethodCloned */,
      40,    1,  292,    2, 0x0a /* Public */,
      42,    1,  295,    2, 0x0a /* Public */,
      43,    1,  298,    2, 0x0a /* Public */,
      45,    1,  301,    2, 0x0a /* Public */,
      47,    0,  304,    2, 0x0a /* Public */,
      48,    0,  305,    2, 0x0a /* Public */,
      49,    0,  306,    2, 0x0a /* Public */,
      50,    0,  307,    2, 0x0a /* Public */,
      51,    0,  308,    2, 0x0a /* Public */,
      52,    0,  309,    2, 0x0a /* Public */,
      53,    0,  310,    2, 0x0a /* Public */,
      54,    0,  311,    2, 0x0a /* Public */,
      55,    2,  312,    2, 0x0a /* Public */,
      59,    0,  317,    2, 0x0a /* Public */,
      60,    0,  318,    2, 0x0a /* Public */,
      61,    1,  319,    2, 0x0a /* Public */,
      63,    0,  322,    2, 0x0a /* Public */,
      64,    0,  323,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QStringList,    6,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::ULongLong, QMetaType::ULongLong,   14,   15,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, 0x80000000 | 20,   18,
    QMetaType::Void, 0x80000000 | 22,   18,
    QMetaType::Void, QMetaType::QPoint,   24,
    QMetaType::Void, QMetaType::QPoint,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Bool,   38,   37,   39,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   38,   37,
    QMetaType::Void, QMetaType::Int,   41,
    QMetaType::Void, QMetaType::Int,   41,
    QMetaType::Void, QMetaType::QString,   44,
    QMetaType::Void, QMetaType::Int,   46,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 56, 0x80000000 | 56,   57,   58,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   62,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void RPCConsole::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        RPCConsole *_t = static_cast<RPCConsole *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->stopExecutor(); break;
        case 1: _t->cmdRequest((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->handleRestart((*reinterpret_cast< QStringList(*)>(_a[1]))); break;
        case 3: _t->on_lineEdit_returnPressed(); break;
        case 4: _t->on_tabWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_openDebugLogfileButton_clicked(); break;
        case 6: _t->on_sldGraphRange_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->updateTrafficStats((*reinterpret_cast< quint64(*)>(_a[1])),(*reinterpret_cast< quint64(*)>(_a[2]))); break;
        case 8: _t->resizeEvent((*reinterpret_cast< QResizeEvent*(*)>(_a[1]))); break;
        case 9: _t->showEvent((*reinterpret_cast< QShowEvent*(*)>(_a[1]))); break;
        case 10: _t->hideEvent((*reinterpret_cast< QHideEvent*(*)>(_a[1]))); break;
        case 11: _t->showPeersTableContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 12: _t->showBanTableContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 13: _t->showOrHideBanTableIfRequired(); break;
        case 14: _t->clearSelectedNode(); break;
        case 15: _t->clear(); break;
        case 16: _t->walletSalvage(); break;
        case 17: _t->walletRescan(); break;
        case 18: _t->walletZaptxes1(); break;
        case 19: _t->walletZaptxes2(); break;
        case 20: _t->walletUpgrade(); break;
        case 21: _t->walletReindex(); break;
        case 22: _t->walletResync(); break;
        case 23: _t->reject(); break;
        case 24: _t->message((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 25: _t->message((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 26: _t->setNumConnections((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->setNumBlocks((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->setMasternodeCount((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 29: _t->browseHistory((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->scrollToEnd(); break;
        case 31: _t->showInfo(); break;
        case 32: _t->showConsole(); break;
        case 33: _t->showNetwork(); break;
        case 34: _t->showPeers(); break;
        case 35: _t->showRepair(); break;
        case 36: _t->showConfEditor(); break;
        case 37: _t->showMNConfEditor(); break;
        case 38: _t->peerSelected((*reinterpret_cast< const QItemSelection(*)>(_a[1])),(*reinterpret_cast< const QItemSelection(*)>(_a[2]))); break;
        case 39: _t->peerLayoutChanged(); break;
        case 40: _t->disconnectSelectedNode(); break;
        case 41: _t->banSelectedNode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 42: _t->unbanSelectedNode(); break;
        case 43: _t->showBackups(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (RPCConsole::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RPCConsole::stopExecutor)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (RPCConsole::*_t)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RPCConsole::cmdRequest)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (RPCConsole::*_t)(QStringList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RPCConsole::handleRestart)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject RPCConsole::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_RPCConsole.data,
      qt_meta_data_RPCConsole,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *RPCConsole::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RPCConsole::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RPCConsole.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int RPCConsole::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 44)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 44;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 44)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 44;
    }
    return _id;
}

// SIGNAL 0
void RPCConsole::stopExecutor()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void RPCConsole::cmdRequest(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void RPCConsole::handleRestart(QStringList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
