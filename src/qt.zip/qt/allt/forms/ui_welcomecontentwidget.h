/********************************************************************************
** Form generated from reading UI file 'welcomecontentwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WELCOMECONTENTWIDGET_H
#define UI_WELCOMECONTENTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qt/allt/pfborderimage.h"

QT_BEGIN_NAMESPACE

class Ui_WelcomeContentWidget
{
public:
    QVBoxLayout *verticalLayout;
    PFBorderImage *frame_2;
    QVBoxLayout *verticalLayout_1;
    QWidget *container;
    QVBoxLayout *verticalLayout_2;
    QWidget *frame;
    QVBoxLayout *verticalLayout_3;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonSkip;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_7;
    QWidget *layoutIcon1_2;
    QVBoxLayout *layoutIcon1;
    QPushButton *pushNumber1;
    QLabel *labelLine1;
    QWidget *layoutIcon2_2;
    QVBoxLayout *layoutIcon2;
    QPushButton *pushNumber2;
    QLabel *labelLine2;
    QWidget *layoutIcon3_2;
    QVBoxLayout *layoutIcon3;
    QPushButton *pushNumber3;
    QLabel *labelLine3;
    QWidget *layoutIcon4_2;
    QVBoxLayout *layoutIcon4;
    QPushButton *pushNumber4;
    QSpacerItem *horizontalSpacer_8;
    QWidget *groupContainer;
    QHBoxLayout *horizontalLayout_3;
    QGroupBox *groupBoxName;
    QHBoxLayout *horizontalgroup;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *pushName1;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *pushName2;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushName3;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushName4;
    QSpacerItem *horizontalSpacer_6;
    QStackedWidget *stackedWidget;
    QWidget *page_0;
    QVBoxLayout *verticalLayout_4;
    QSpacerItem *verticalSpacer_1;
    QWidget *page_1;
    QVBoxLayout *verticalLayout_5;
    QSpacerItem *verticalSpacer_2;
    QLabel *labelTitle1;
    QSpacerItem *verticalSpacer_3;
    QComboBox *comboBoxLanguage;
    QSpacerItem *verticalSpacer_4;
    QWidget *page_2;
    QVBoxLayout *verticalLayout_6;
    QSpacerItem *verticalSpacer_5;
    QWidget *widget_3;
    QVBoxLayout *verticalLayout_7;
    QLabel *labelTitle2;
    QSpacerItem *verticalSpacer_5_1;
    QLabel *labelMessage2;
    QSpacerItem *verticalSpacer_5_2;
    QWidget *page_3;
    QVBoxLayout *verticalLayout_8;
    QSpacerItem *verticalSpacer_6;
    QLabel *labelTitle3;
    QSpacerItem *verticalSpacer_7;
    QLabel *labelMessage3;
    QWidget *page_4;
    QVBoxLayout *verticalLayout_9;
    QSpacerItem *verticalSpacer_8;
    QLabel *labelTitle4;
    QSpacerItem *verticalSpacer_9;
    QLabel *labelMessage4;
    QSpacerItem *verticalSpacer_10;

    void setupUi(QDialog *WelcomeContentWidget)
    {
        if (WelcomeContentWidget->objectName().isEmpty())
            WelcomeContentWidget->setObjectName(QStringLiteral("WelcomeContentWidget"));
        WelcomeContentWidget->resize(1200, 750);
        verticalLayout = new QVBoxLayout(WelcomeContentWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        frame_2 = new PFBorderImage(WelcomeContentWidget);
        frame_2->setObjectName(QStringLiteral("frame_2"));
        verticalLayout_1 = new QVBoxLayout(frame_2);
        verticalLayout_1->setSpacing(0);
        verticalLayout_1->setObjectName(QStringLiteral("verticalLayout_1"));
        verticalLayout_1->setContentsMargins(0, 0, 0, 0);
        container = new QWidget(frame_2);
        container->setObjectName(QStringLiteral("container"));
        container->setMinimumSize(QSize(880, 520));
        container->setMaximumSize(QSize(880, 520));
        verticalLayout_2 = new QVBoxLayout(container);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(30, -1, 30, -1);
        frame = new QWidget(container);
        frame->setObjectName(QStringLiteral("frame"));
        verticalLayout_3 = new QVBoxLayout(frame);
        verticalLayout_3->setSpacing(0);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(1, 1, 1, 1);
        verticalSpacer = new QSpacerItem(20, 14, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout_3->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(0);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(-1, -1, 20, -1);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer);

        pushButtonSkip = new QPushButton(frame);
        pushButtonSkip->setObjectName(QStringLiteral("pushButtonSkip"));
        pushButtonSkip->setMinimumSize(QSize(20, 20));
        pushButtonSkip->setMaximumSize(QSize(20, 20));

        horizontalLayout_2->addWidget(pushButtonSkip);


        verticalLayout_3->addLayout(horizontalLayout_2);

        widget_2 = new QWidget(frame);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        widget_2->setMinimumSize(QSize(0, 24));
        widget_2->setMaximumSize(QSize(16777215, 24));
        horizontalLayout = new QHBoxLayout(widget_2);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_7 = new QSpacerItem(140, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_7);

        layoutIcon1_2 = new QWidget(widget_2);
        layoutIcon1_2->setObjectName(QStringLiteral("layoutIcon1_2"));
        layoutIcon1_2->setMinimumSize(QSize(22, 22));
        layoutIcon1_2->setMaximumSize(QSize(22, 22));
        layoutIcon1 = new QVBoxLayout(layoutIcon1_2);
        layoutIcon1->setSpacing(0);
        layoutIcon1->setObjectName(QStringLiteral("layoutIcon1"));
        layoutIcon1->setContentsMargins(0, 0, 0, 0);
        pushNumber1 = new QPushButton(layoutIcon1_2);
        pushNumber1->setObjectName(QStringLiteral("pushNumber1"));
        pushNumber1->setMinimumSize(QSize(22, 22));
        pushNumber1->setMaximumSize(QSize(22, 22));
        pushNumber1->setFocusPolicy(Qt::NoFocus);
        pushNumber1->setCheckable(true);
        pushNumber1->setChecked(true);
        pushNumber1->setAutoExclusive(true);

        layoutIcon1->addWidget(pushNumber1, 0, Qt::AlignVCenter);


        horizontalLayout->addWidget(layoutIcon1_2);

        labelLine1 = new QLabel(widget_2);
        labelLine1->setObjectName(QStringLiteral("labelLine1"));
        labelLine1->setMinimumSize(QSize(0, 1));
        labelLine1->setMaximumSize(QSize(16777215, 1));
        labelLine1->setStyleSheet(QStringLiteral(""));

        horizontalLayout->addWidget(labelLine1, 0, Qt::AlignVCenter);

        layoutIcon2_2 = new QWidget(widget_2);
        layoutIcon2_2->setObjectName(QStringLiteral("layoutIcon2_2"));
        layoutIcon2_2->setMinimumSize(QSize(22, 22));
        layoutIcon2_2->setMaximumSize(QSize(22, 22));
        layoutIcon2 = new QVBoxLayout(layoutIcon2_2);
        layoutIcon2->setSpacing(0);
        layoutIcon2->setObjectName(QStringLiteral("layoutIcon2"));
        layoutIcon2->setContentsMargins(0, 0, 0, 0);
        pushNumber2 = new QPushButton(layoutIcon2_2);
        pushNumber2->setObjectName(QStringLiteral("pushNumber2"));
        pushNumber2->setMinimumSize(QSize(22, 22));
        pushNumber2->setMaximumSize(QSize(22, 22));
        pushNumber2->setFocusPolicy(Qt::NoFocus);
        pushNumber2->setCheckable(true);
        pushNumber2->setChecked(false);
        pushNumber2->setAutoExclusive(true);

        layoutIcon2->addWidget(pushNumber2, 0, Qt::AlignVCenter);


        horizontalLayout->addWidget(layoutIcon2_2);

        labelLine2 = new QLabel(widget_2);
        labelLine2->setObjectName(QStringLiteral("labelLine2"));
        labelLine2->setMinimumSize(QSize(0, 1));
        labelLine2->setMaximumSize(QSize(16777215, 1));
        labelLine2->setStyleSheet(QStringLiteral(""));

        horizontalLayout->addWidget(labelLine2);

        layoutIcon3_2 = new QWidget(widget_2);
        layoutIcon3_2->setObjectName(QStringLiteral("layoutIcon3_2"));
        layoutIcon3_2->setMinimumSize(QSize(22, 22));
        layoutIcon3_2->setMaximumSize(QSize(22, 22));
        layoutIcon3 = new QVBoxLayout(layoutIcon3_2);
        layoutIcon3->setSpacing(0);
        layoutIcon3->setObjectName(QStringLiteral("layoutIcon3"));
        layoutIcon3->setContentsMargins(0, 0, 0, 0);
        pushNumber3 = new QPushButton(layoutIcon3_2);
        pushNumber3->setObjectName(QStringLiteral("pushNumber3"));
        pushNumber3->setMinimumSize(QSize(22, 22));
        pushNumber3->setMaximumSize(QSize(22, 22));
        pushNumber3->setFocusPolicy(Qt::NoFocus);
        pushNumber3->setCheckable(true);
        pushNumber3->setChecked(false);
        pushNumber3->setAutoExclusive(true);

        layoutIcon3->addWidget(pushNumber3, 0, Qt::AlignVCenter);


        horizontalLayout->addWidget(layoutIcon3_2);

        labelLine3 = new QLabel(widget_2);
        labelLine3->setObjectName(QStringLiteral("labelLine3"));
        labelLine3->setMinimumSize(QSize(0, 1));
        labelLine3->setMaximumSize(QSize(16777215, 1));
        labelLine3->setStyleSheet(QStringLiteral(""));

        horizontalLayout->addWidget(labelLine3);

        layoutIcon4_2 = new QWidget(widget_2);
        layoutIcon4_2->setObjectName(QStringLiteral("layoutIcon4_2"));
        layoutIcon4_2->setMinimumSize(QSize(22, 22));
        layoutIcon4_2->setMaximumSize(QSize(22, 22));
        layoutIcon4 = new QVBoxLayout(layoutIcon4_2);
        layoutIcon4->setSpacing(0);
        layoutIcon4->setObjectName(QStringLiteral("layoutIcon4"));
        layoutIcon4->setContentsMargins(0, 0, 0, 0);
        pushNumber4 = new QPushButton(layoutIcon4_2);
        pushNumber4->setObjectName(QStringLiteral("pushNumber4"));
        pushNumber4->setMinimumSize(QSize(22, 22));
        pushNumber4->setMaximumSize(QSize(22, 22));
        pushNumber4->setFocusPolicy(Qt::NoFocus);
        pushNumber4->setCheckable(true);
        pushNumber4->setChecked(false);
        pushNumber4->setAutoExclusive(true);

        layoutIcon4->addWidget(pushNumber4, 0, Qt::AlignVCenter);


        horizontalLayout->addWidget(layoutIcon4_2);

        horizontalSpacer_8 = new QSpacerItem(140, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_8);


        verticalLayout_3->addWidget(widget_2);

        groupContainer = new QWidget(frame);
        groupContainer->setObjectName(QStringLiteral("groupContainer"));
        groupContainer->setAutoFillBackground(true);
        horizontalLayout_3 = new QHBoxLayout(groupContainer);
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        groupBoxName = new QGroupBox(groupContainer);
        groupBoxName->setObjectName(QStringLiteral("groupBoxName"));
        groupBoxName->setAutoFillBackground(true);
        horizontalgroup = new QHBoxLayout(groupBoxName);
        horizontalgroup->setSpacing(0);
        horizontalgroup->setObjectName(QStringLiteral("horizontalgroup"));
        horizontalgroup->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_9 = new QSpacerItem(96, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalgroup->addItem(horizontalSpacer_9);

        pushName1 = new QPushButton(groupBoxName);
        pushName1->setObjectName(QStringLiteral("pushName1"));
        pushName1->setMinimumSize(QSize(110, 0));
        pushName1->setMaximumSize(QSize(100, 16777215));
        pushName1->setFocusPolicy(Qt::NoFocus);
        pushName1->setCheckable(true);
        pushName1->setChecked(true);
        pushName1->setAutoExclusive(false);

        horizontalgroup->addWidget(pushName1);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalgroup->addItem(horizontalSpacer_4);

        pushName2 = new QPushButton(groupBoxName);
        pushName2->setObjectName(QStringLiteral("pushName2"));
        pushName2->setMinimumSize(QSize(110, 0));
        pushName2->setMaximumSize(QSize(100, 16777215));
        pushName2->setFocusPolicy(Qt::NoFocus);
        pushName2->setCheckable(true);
        pushName2->setAutoExclusive(false);

        horizontalgroup->addWidget(pushName2);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalgroup->addItem(horizontalSpacer_3);

        pushName3 = new QPushButton(groupBoxName);
        pushName3->setObjectName(QStringLiteral("pushName3"));
        pushName3->setMinimumSize(QSize(110, 0));
        pushName3->setMaximumSize(QSize(100, 16777215));
        pushName3->setFocusPolicy(Qt::NoFocus);
        pushName3->setCheckable(true);
        pushName3->setAutoExclusive(false);

        horizontalgroup->addWidget(pushName3);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalgroup->addItem(horizontalSpacer_2);

        pushName4 = new QPushButton(groupBoxName);
        pushName4->setObjectName(QStringLiteral("pushName4"));
        pushName4->setMinimumSize(QSize(110, 0));
        pushName4->setMaximumSize(QSize(100, 16777215));
        pushName4->setFocusPolicy(Qt::NoFocus);
        pushName4->setCheckable(true);
        pushName4->setAutoExclusive(false);

        horizontalgroup->addWidget(pushName4);

        horizontalSpacer_6 = new QSpacerItem(96, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalgroup->addItem(horizontalSpacer_6);


        horizontalLayout_3->addWidget(groupBoxName);


        verticalLayout_3->addWidget(groupContainer);

        stackedWidget = new QStackedWidget(frame);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        page_0 = new QWidget();
        page_0->setObjectName(QStringLiteral("page_0"));
        verticalLayout_4 = new QVBoxLayout(page_0);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(40, -1, 40, -1);
        verticalSpacer_1 = new QSpacerItem(20, 60, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout_4->addItem(verticalSpacer_1);

        stackedWidget->addWidget(page_0);
        page_1 = new QWidget();
        page_1->setObjectName(QStringLiteral("page_1"));
        verticalLayout_5 = new QVBoxLayout(page_1);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(200, 12, 200, 12);
        verticalSpacer_2 = new QSpacerItem(20, 60, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_5->addItem(verticalSpacer_2);

        labelTitle1 = new QLabel(page_1);
        labelTitle1->setObjectName(QStringLiteral("labelTitle1"));
        labelTitle1->setMinimumSize(QSize(0, 50));
        labelTitle1->setMaximumSize(QSize(16777215, 50));

        verticalLayout_5->addWidget(labelTitle1, 0, Qt::AlignHCenter);

        verticalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_3);

        comboBoxLanguage = new QComboBox(page_1);
        comboBoxLanguage->setObjectName(QStringLiteral("comboBoxLanguage"));

        verticalLayout_5->addWidget(comboBoxLanguage);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_4);

        stackedWidget->addWidget(page_1);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        verticalLayout_6 = new QVBoxLayout(page_2);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(40, -1, 40, -1);
        verticalSpacer_5 = new QSpacerItem(20, 60, QSizePolicy::Minimum, QSizePolicy::Minimum);

        verticalLayout_6->addItem(verticalSpacer_5);

        widget_3 = new QWidget(page_2);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        verticalLayout_7 = new QVBoxLayout(widget_3);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        labelTitle2 = new QLabel(widget_3);
        labelTitle2->setObjectName(QStringLiteral("labelTitle2"));
        labelTitle2->setMaximumSize(QSize(16777215, 60));
        labelTitle2->setStyleSheet(QStringLiteral("padding:1px;"));
        labelTitle2->setAlignment(Qt::AlignCenter);

        verticalLayout_7->addWidget(labelTitle2, 0, Qt::AlignHCenter);

        verticalSpacer_5_1 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_7->addItem(verticalSpacer_5_1);

        labelMessage2 = new QLabel(widget_3);
        labelMessage2->setObjectName(QStringLiteral("labelMessage2"));
        labelMessage2->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        labelMessage2->setWordWrap(true);

        verticalLayout_7->addWidget(labelMessage2, 0, Qt::AlignHCenter);

        verticalSpacer_5_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_5_2);

        verticalLayout_7->setStretch(0, 1);
        verticalLayout_7->setStretch(2, 1);

        verticalLayout_6->addWidget(widget_3);

        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        verticalLayout_8 = new QVBoxLayout(page_3);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(140, 12, 140, 12);
        verticalSpacer_6 = new QSpacerItem(20, 60, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_6);

        labelTitle3 = new QLabel(page_3);
        labelTitle3->setObjectName(QStringLiteral("labelTitle3"));
        labelTitle3->setMinimumSize(QSize(0, 50));
        labelTitle3->setMaximumSize(QSize(16777215, 50));

        verticalLayout_8->addWidget(labelTitle3, 0, Qt::AlignHCenter);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_8->addItem(verticalSpacer_7);

        labelMessage3 = new QLabel(page_3);
        labelMessage3->setObjectName(QStringLiteral("labelMessage3"));
        labelMessage3->setAlignment(Qt::AlignHCenter|Qt::AlignTop);
        labelMessage3->setWordWrap(true);

        verticalLayout_8->addWidget(labelMessage3);

        verticalLayout_8->setStretch(3, 3);
        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QStringLiteral("page_4"));
        verticalLayout_9 = new QVBoxLayout(page_4);
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(140, 12, 140, 12);
        verticalSpacer_8 = new QSpacerItem(20, 60, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_9->addItem(verticalSpacer_8);

        labelTitle4 = new QLabel(page_4);
        labelTitle4->setObjectName(QStringLiteral("labelTitle4"));
        labelTitle4->setMinimumSize(QSize(0, 50));
        labelTitle4->setMaximumSize(QSize(16777215, 50));

        verticalLayout_9->addWidget(labelTitle4, 0, Qt::AlignHCenter);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_9->addItem(verticalSpacer_9);

        labelMessage4 = new QLabel(page_4);
        labelMessage4->setObjectName(QStringLiteral("labelMessage4"));
        labelMessage4->setAlignment(Qt::AlignCenter);
        labelMessage4->setWordWrap(true);

        verticalLayout_9->addWidget(labelMessage4);

        verticalSpacer_10 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_10);

        stackedWidget->addWidget(page_4);

        verticalLayout_3->addWidget(stackedWidget);


        verticalLayout_2->addWidget(frame);


        verticalLayout_1->addWidget(container, 0, Qt::AlignHCenter|Qt::AlignVCenter);


        verticalLayout->addWidget(frame_2);


        retranslateUi(WelcomeContentWidget);

        QMetaObject::connectSlotsByName(WelcomeContentWidget);
    } // setupUi

    void retranslateUi(QDialog *WelcomeContentWidget)
    {
        WelcomeContentWidget->setWindowTitle(QString());
        pushButtonSkip->setText(QString());
        pushNumber1->setText(QApplication::translate("WelcomeContentWidget", "1", Q_NULLPTR));
        labelLine1->setText(QString());
        pushNumber2->setText(QApplication::translate("WelcomeContentWidget", "2", Q_NULLPTR));
        labelLine2->setText(QString());
        pushNumber3->setText(QApplication::translate("WelcomeContentWidget", "3", Q_NULLPTR));
        labelLine3->setText(QString());
        pushNumber4->setText(QApplication::translate("WelcomeContentWidget", "4", Q_NULLPTR));
        groupBoxName->setTitle(QString());
        pushName1->setText(QApplication::translate("WelcomeContentWidget", "Language", Q_NULLPTR));
        pushName2->setText(QApplication::translate("WelcomeContentWidget", "Welcome", Q_NULLPTR));
        pushName3->setText(QApplication::translate("WelcomeContentWidget", "Privacy", Q_NULLPTR));
        pushName4->setText(QApplication::translate("WelcomeContentWidget", "Masternodes", Q_NULLPTR));
        labelTitle1->setText(QApplication::translate("WelcomeContentWidget", "Select your language", Q_NULLPTR));
        labelTitle2->setText(QApplication::translate("WelcomeContentWidget", "Welcome to\n"
"allt Coin Wallet", Q_NULLPTR));
        labelMessage2->setText(QApplication::translate("WelcomeContentWidget", "allt is the world\342\200\231s most innovative Proof of Stake blockchain based technology. Developed by a team of highly experienced developers and cryptographers.", Q_NULLPTR));
        labelTitle3->setText(QApplication::translate("WelcomeContentWidget", "How allt respects your privacy?", Q_NULLPTR));
        labelMessage3->setText(QApplication::translate("WelcomeContentWidget", "<html><head/><body><p>As our manifesto says: Privacy is a non-negotiable basic human right; it grants users the freedom to share their data whenever and with whomever they want - allt believes in self sovereignty.</p></body></html>", Q_NULLPTR));
        labelTitle4->setText(QApplication::translate("WelcomeContentWidget", "What is a Masternode?", Q_NULLPTR));
        labelMessage4->setText(QApplication::translate("WelcomeContentWidget", "The masternode network is allt's second layer network on top of the blockchain that enables our DAO to provide decentralized governance and a treasury.", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class WelcomeContentWidget: public Ui_WelcomeContentWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WELCOMECONTENTWIDGET_H
