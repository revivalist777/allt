/****************************************************************************
** Meta object code from reading C++ file 'coldstakingwidget.h'
**
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "qt/allt/coldstakingwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'coldstakingwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ColdStakingWidget_t {
    QByteArrayData data[36];
    char stringdata0[500];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ColdStakingWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ColdStakingWidget_t qt_meta_stringdata_ColdStakingWidget = {
    {
QT_MOC_LITERAL(0, 0, 17), // "ColdStakingWidget"
QT_MOC_LITERAL(1, 18, 12), // "walletSynced"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 4), // "sync"
QT_MOC_LITERAL(4, 37, 11), // "changeTheme"
QT_MOC_LITERAL(5, 49, 12), // "isLightTheme"
QT_MOC_LITERAL(6, 62, 8), // "QString&"
QT_MOC_LITERAL(7, 71, 5), // "theme"
QT_MOC_LITERAL(8, 77, 20), // "handleAddressClicked"
QT_MOC_LITERAL(9, 98, 5), // "index"
QT_MOC_LITERAL(10, 104, 26), // "handleMyColdAddressClicked"
QT_MOC_LITERAL(11, 131, 6), // "rIndex"
QT_MOC_LITERAL(12, 138, 20), // "onCoinControlClicked"
QT_MOC_LITERAL(13, 159, 18), // "onColdStakeClicked"
QT_MOC_LITERAL(14, 178, 17), // "updateDisplayUnit"
QT_MOC_LITERAL(15, 196, 8), // "showList"
QT_MOC_LITERAL(16, 205, 4), // "show"
QT_MOC_LITERAL(17, 210, 13), // "onSendClicked"
QT_MOC_LITERAL(18, 224, 18), // "onDelegateSelected"
QT_MOC_LITERAL(19, 243, 8), // "delegate"
QT_MOC_LITERAL(20, 252, 13), // "onEditClicked"
QT_MOC_LITERAL(21, 266, 15), // "onDeleteClicked"
QT_MOC_LITERAL(22, 282, 13), // "onCopyClicked"
QT_MOC_LITERAL(23, 296, 18), // "onCopyOwnerClicked"
QT_MOC_LITERAL(24, 315, 20), // "onAddressCopyClicked"
QT_MOC_LITERAL(25, 336, 20), // "onAddressEditClicked"
QT_MOC_LITERAL(26, 357, 11), // "onTxArrived"
QT_MOC_LITERAL(27, 369, 4), // "hash"
QT_MOC_LITERAL(28, 374, 11), // "isCoinStake"
QT_MOC_LITERAL(29, 386, 11), // "isCSAnyType"
QT_MOC_LITERAL(30, 398, 17), // "onContactsClicked"
QT_MOC_LITERAL(31, 416, 8), // "ownerAdd"
QT_MOC_LITERAL(32, 425, 8), // "clearAll"
QT_MOC_LITERAL(33, 434, 14), // "onLabelClicked"
QT_MOC_LITERAL(34, 449, 27), // "onMyStakingAddressesClicked"
QT_MOC_LITERAL(35, 477, 22) // "onDelegationsRefreshed"

    },
    "ColdStakingWidget\0walletSynced\0\0sync\0"
    "changeTheme\0isLightTheme\0QString&\0"
    "theme\0handleAddressClicked\0index\0"
    "handleMyColdAddressClicked\0rIndex\0"
    "onCoinControlClicked\0onColdStakeClicked\0"
    "updateDisplayUnit\0showList\0show\0"
    "onSendClicked\0onDelegateSelected\0"
    "delegate\0onEditClicked\0onDeleteClicked\0"
    "onCopyClicked\0onCopyOwnerClicked\0"
    "onAddressCopyClicked\0onAddressEditClicked\0"
    "onTxArrived\0hash\0isCoinStake\0isCSAnyType\0"
    "onContactsClicked\0ownerAdd\0clearAll\0"
    "onLabelClicked\0onMyStakingAddressesClicked\0"
    "onDelegationsRefreshed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ColdStakingWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  124,    2, 0x0a /* Public */,
       4,    2,  127,    2, 0x08 /* Private */,
       8,    1,  132,    2, 0x08 /* Private */,
      10,    1,  135,    2, 0x08 /* Private */,
      12,    0,  138,    2, 0x08 /* Private */,
      13,    0,  139,    2, 0x08 /* Private */,
      14,    0,  140,    2, 0x08 /* Private */,
      15,    1,  141,    2, 0x08 /* Private */,
      17,    0,  144,    2, 0x08 /* Private */,
      18,    1,  145,    2, 0x08 /* Private */,
      20,    0,  148,    2, 0x08 /* Private */,
      21,    0,  149,    2, 0x08 /* Private */,
      22,    0,  150,    2, 0x08 /* Private */,
      23,    0,  151,    2, 0x08 /* Private */,
      24,    0,  152,    2, 0x08 /* Private */,
      25,    0,  153,    2, 0x08 /* Private */,
      26,    3,  154,    2, 0x08 /* Private */,
      30,    1,  161,    2, 0x08 /* Private */,
      32,    0,  164,    2, 0x08 /* Private */,
      33,    0,  165,    2, 0x08 /* Private */,
      34,    0,  166,    2, 0x08 /* Private */,
      35,    0,  167,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 6,    5,    7,
    QMetaType::Void, QMetaType::QModelIndex,    9,
    QMetaType::Void, QMetaType::QModelIndex,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,   27,   28,   29,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ColdStakingWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ColdStakingWidget *_t = static_cast<ColdStakingWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->walletSynced((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->changeTheme((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 2: _t->handleAddressClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 3: _t->handleMyColdAddressClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 4: _t->onCoinControlClicked(); break;
        case 5: _t->onColdStakeClicked(); break;
        case 6: _t->updateDisplayUnit(); break;
        case 7: _t->showList((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->onSendClicked(); break;
        case 9: _t->onDelegateSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->onEditClicked(); break;
        case 11: _t->onDeleteClicked(); break;
        case 12: _t->onCopyClicked(); break;
        case 13: _t->onCopyOwnerClicked(); break;
        case 14: _t->onAddressCopyClicked(); break;
        case 15: _t->onAddressEditClicked(); break;
        case 16: _t->onTxArrived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const bool(*)>(_a[2])),(*reinterpret_cast< const bool(*)>(_a[3]))); break;
        case 17: _t->onContactsClicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->clearAll(); break;
        case 19: _t->onLabelClicked(); break;
        case 20: _t->onMyStakingAddressesClicked(); break;
        case 21: _t->onDelegationsRefreshed(); break;
        default: ;
        }
    }
}

const QMetaObject ColdStakingWidget::staticMetaObject = {
    { &PWidget::staticMetaObject, qt_meta_stringdata_ColdStakingWidget.data,
      qt_meta_data_ColdStakingWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ColdStakingWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ColdStakingWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ColdStakingWidget.stringdata0))
        return static_cast<void*>(this);
    return PWidget::qt_metacast(_clname);
}

int ColdStakingWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = PWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
