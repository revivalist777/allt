/********************************************************************************
** Form generated from reading UI file 'settingsfaqwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGSFAQWIDGET_H
#define UI_SETTINGSFAQWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qt/allt/pfborderimage.h"

QT_BEGIN_NAMESPACE

class Ui_SettingsFaqWidget
{
public:
    QHBoxLayout *horizontalLayout;
    PFBorderImage *container;
    QVBoxLayout *verticalLayoutcont;
    QHBoxLayout *horizontalLayout_3;
    QLabel *labelTitle;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButtonExit;
    QHBoxLayout *horizontalLayout_6;
    QWidget *left;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QWidget *containerButtons;
    QVBoxLayout *verticalLayout;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout_9;
    QPushButton *pushButtonFaq1;
    QPushButton *pushButtonFaq2;
    QPushButton *pushButtonFaq3;
    QPushButton *pushButtonFaq4;
    QPushButton *pushButtonFaq5;
    QPushButton *pushButtonFaq6;
    QPushButton *pushButtonFaq7;
    QPushButton *pushButtonFaq8;
    QPushButton *pushButtonFaq9;
    QPushButton *pushButtonFaq10;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelWebLink;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *pushButtonWebLink;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *horizontalSpacer_3;
    QWidget *right;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_6;
    QScrollArea *scrollAreaFaq;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *verticalLayout_7;
    QWidget *widgetFaq1;
    QHBoxLayout *horizontalLayout_1;
    QLabel *labelNumber1;
    QVBoxLayout *verticalLayout_61;
    QLabel *labelSubtitle1;
    QSpacerItem *verticalSpacer_10;
    QLabel *labelContent1;
    QSpacerItem *verticalSpacer_11;
    QWidget *widgetFaq2;
    QHBoxLayout *horizontalPage2;
    QLabel *labelNumber2;
    QVBoxLayout *verticalLayoutPage2;
    QLabel *labelSubtitle2;
    QSpacerItem *verticalSpacer_20;
    QLabel *labelContent2;
    QSpacerItem *verticalSpacer_21;
    QWidget *widgetFaq3;
    QHBoxLayout *horizontalpage_3;
    QLabel *labelNumber3;
    QVBoxLayout *verticalLayoutpage_3;
    QLabel *labelSubtitle3;
    QSpacerItem *verticalSpacer_30;
    QLabel *labelContent3;
    QSpacerItem *verticalSpacer_31;
    QWidget *widgetFaq4;
    QHBoxLayout *horizontalPage_4;
    QLabel *labelNumber4;
    QVBoxLayout *verticalLayoutPage_4;
    QLabel *labelSubtitle4;
    QSpacerItem *verticalSpacer_40;
    QLabel *labelContent4;
    QSpacerItem *verticalSpacer_41;
    QWidget *widgetFaq5;
    QHBoxLayout *horizontalPage_5;
    QLabel *labelNumber5;
    QVBoxLayout *verticalLayoutPage_5;
    QLabel *labelSubtitle5;
    QSpacerItem *verticalSpacer_50;
    QLabel *labelContent5;
    QSpacerItem *verticalSpacer_51;
    QWidget *widgetFaq6;
    QHBoxLayout *horizontalpage_6;
    QLabel *labelNumber6;
    QVBoxLayout *verticalLayoutpage_6;
    QLabel *labelSubtitle6;
    QSpacerItem *verticalSpacer_60;
    QLabel *labelContent6;
    QSpacerItem *verticalSpacer_61;
    QWidget *widgetFaq7;
    QHBoxLayout *horizontalpage_7;
    QLabel *labelNumber7;
    QVBoxLayout *verticalLayoutpage_7;
    QLabel *labelSubtitle7;
    QSpacerItem *verticalSpacer_70;
    QLabel *labelContent7;
    QSpacerItem *verticalSpacer_71;
    QWidget *widgetFaq8;
    QHBoxLayout *horizontalpage_8;
    QLabel *labelNumber8;
    QVBoxLayout *verticalLayoutpage_8;
    QLabel *labelSubtitle8;
    QSpacerItem *verticalSpacer_80;
    QLabel *labelContent8;
    QSpacerItem *verticalSpacer_81;
    QWidget *widgetFaq9;
    QHBoxLayout *horizontalpage_9;
    QLabel *labelNumber9;
    QVBoxLayout *verticalLayoutpage_9;
    QLabel *labelSubtitle9;
    QSpacerItem *verticalSpacer_90;
    QLabel *labelContent9;
    QSpacerItem *verticalSpacer_91;
    QWidget *widgetFaq10;
    QHBoxLayout *horizontalpage_10;
    QLabel *labelNumber10;
    QVBoxLayout *verticalLayoutpage_10;
    QLabel *labelSubtitle10;
    QSpacerItem *verticalSpacer_100;
    QLabel *labelContent10;
    QSpacerItem *verticalSpacer_92;

    void setupUi(QWidget *SettingsFaqWidget)
    {
        if (SettingsFaqWidget->objectName().isEmpty())
            SettingsFaqWidget->setObjectName(QStringLiteral("SettingsFaqWidget"));
        SettingsFaqWidget->resize(1203, 1741);
        horizontalLayout = new QHBoxLayout(SettingsFaqWidget);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        container = new PFBorderImage(SettingsFaqWidget);
        container->setObjectName(QStringLiteral("container"));
        verticalLayoutcont = new QVBoxLayout(container);
        verticalLayoutcont->setObjectName(QStringLiteral("verticalLayoutcont"));
        verticalLayoutcont->setContentsMargins(36, 44, 36, 44);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(10, -1, 10, -1);
        labelTitle = new QLabel(container);
        labelTitle->setObjectName(QStringLiteral("labelTitle"));

        horizontalLayout_3->addWidget(labelTitle);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        pushButtonExit = new QPushButton(container);
        pushButtonExit->setObjectName(QStringLiteral("pushButtonExit"));

        horizontalLayout_3->addWidget(pushButtonExit);


        verticalLayoutcont->addLayout(horizontalLayout_3);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        left = new QWidget(container);
        left->setObjectName(QStringLiteral("left"));
        verticalLayout_3 = new QVBoxLayout(left);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        containerButtons = new QWidget(left);
        containerButtons->setObjectName(QStringLiteral("containerButtons"));
        verticalLayout = new QVBoxLayout(containerButtons);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        groupBox = new QGroupBox(containerButtons);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        verticalLayout_9 = new QVBoxLayout(groupBox);
        verticalLayout_9->setSpacing(0);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        pushButtonFaq1 = new QPushButton(groupBox);
        pushButtonFaq1->setObjectName(QStringLiteral("pushButtonFaq1"));
        pushButtonFaq1->setMinimumSize(QSize(0, 50));
        pushButtonFaq1->setMaximumSize(QSize(16777215, 50));
        pushButtonFaq1->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq1->setCheckable(true);
        pushButtonFaq1->setChecked(true);
        pushButtonFaq1->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq1);

        pushButtonFaq2 = new QPushButton(groupBox);
        pushButtonFaq2->setObjectName(QStringLiteral("pushButtonFaq2"));
        pushButtonFaq2->setMinimumSize(QSize(0, 50));
        pushButtonFaq2->setMaximumSize(QSize(16777215, 50));
        pushButtonFaq2->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq2->setCheckable(true);
        pushButtonFaq2->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq2);

        pushButtonFaq3 = new QPushButton(groupBox);
        pushButtonFaq3->setObjectName(QStringLiteral("pushButtonFaq3"));
        pushButtonFaq3->setMinimumSize(QSize(0, 50));
        pushButtonFaq3->setMaximumSize(QSize(16777215, 16777215));
        pushButtonFaq3->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq3->setCheckable(true);
        pushButtonFaq3->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq3);

        pushButtonFaq4 = new QPushButton(groupBox);
        pushButtonFaq4->setObjectName(QStringLiteral("pushButtonFaq4"));
        pushButtonFaq4->setMinimumSize(QSize(0, 50));
        pushButtonFaq4->setMaximumSize(QSize(16777215, 16777215));
        pushButtonFaq4->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq4->setCheckable(true);
        pushButtonFaq4->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq4);

        pushButtonFaq5 = new QPushButton(groupBox);
        pushButtonFaq5->setObjectName(QStringLiteral("pushButtonFaq5"));
        pushButtonFaq5->setMinimumSize(QSize(0, 50));
        pushButtonFaq5->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq5->setCheckable(true);
        pushButtonFaq5->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq5);

        pushButtonFaq6 = new QPushButton(groupBox);
        pushButtonFaq6->setObjectName(QStringLiteral("pushButtonFaq6"));
        pushButtonFaq6->setMinimumSize(QSize(0, 50));
        pushButtonFaq6->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq6->setCheckable(true);
        pushButtonFaq6->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq6);

        pushButtonFaq7 = new QPushButton(groupBox);
        pushButtonFaq7->setObjectName(QStringLiteral("pushButtonFaq7"));
        pushButtonFaq7->setMinimumSize(QSize(0, 50));
        pushButtonFaq7->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq7->setCheckable(true);
        pushButtonFaq7->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq7);

        pushButtonFaq8 = new QPushButton(groupBox);
        pushButtonFaq8->setObjectName(QStringLiteral("pushButtonFaq8"));
        pushButtonFaq8->setMinimumSize(QSize(0, 50));
        pushButtonFaq8->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq8->setCheckable(true);
        pushButtonFaq8->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq8);

        pushButtonFaq9 = new QPushButton(groupBox);
        pushButtonFaq9->setObjectName(QStringLiteral("pushButtonFaq9"));
        pushButtonFaq9->setMinimumSize(QSize(0, 50));
        pushButtonFaq9->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq9->setCheckable(true);
        pushButtonFaq9->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq9);

        pushButtonFaq10 = new QPushButton(groupBox);
        pushButtonFaq10->setObjectName(QStringLiteral("pushButtonFaq10"));
        pushButtonFaq10->setMinimumSize(QSize(0, 50));
        pushButtonFaq10->setFocusPolicy(Qt::NoFocus);
        pushButtonFaq10->setCheckable(true);
        pushButtonFaq10->setAutoExclusive(true);

        verticalLayout_9->addWidget(pushButtonFaq10);


        verticalLayout->addWidget(groupBox);


        verticalLayout_2->addWidget(containerButtons);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        labelWebLink = new QLabel(left);
        labelWebLink->setObjectName(QStringLiteral("labelWebLink"));

        horizontalLayout_2->addWidget(labelWebLink);

        horizontalSpacer_4 = new QSpacerItem(10, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        pushButtonWebLink = new QPushButton(left);
        pushButtonWebLink->setObjectName(QStringLiteral("pushButtonWebLink"));
        pushButtonWebLink->setFocusPolicy(Qt::NoFocus);

        horizontalLayout_2->addWidget(pushButtonWebLink);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_2);


        verticalLayout_3->addLayout(verticalLayout_2);


        horizontalLayout_6->addWidget(left);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Minimum, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_3);

        right = new QWidget(container);
        right->setObjectName(QStringLiteral("right"));
        verticalLayout_5 = new QVBoxLayout(right);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(0);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        scrollAreaFaq = new QScrollArea(right);
        scrollAreaFaq->setObjectName(QStringLiteral("scrollAreaFaq"));
        scrollAreaFaq->setStyleSheet(QStringLiteral("#scrollAreaFaq { background:transparent; }"));
        scrollAreaFaq->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        scrollAreaFaq->setSizeAdjustPolicy(QAbstractScrollArea::AdjustIgnored);
        scrollAreaFaq->setWidgetResizable(true);
        scrollAreaFaq->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 628, 2344));
        scrollAreaWidgetContents->setAutoFillBackground(false);
        scrollAreaWidgetContents->setStyleSheet(QStringLiteral("#scrollAreaWidgetContents { background:transparent; }"));
        verticalLayout_7 = new QVBoxLayout(scrollAreaWidgetContents);
        verticalLayout_7->setSpacing(0);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_7->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        widgetFaq1 = new QWidget(scrollAreaWidgetContents);
        widgetFaq1->setObjectName(QStringLiteral("widgetFaq1"));
        widgetFaq1->setMinimumSize(QSize(300, 0));
        horizontalLayout_1 = new QHBoxLayout(widgetFaq1);
        horizontalLayout_1->setObjectName(QStringLiteral("horizontalLayout_1"));
        labelNumber1 = new QLabel(widgetFaq1);
        labelNumber1->setObjectName(QStringLiteral("labelNumber1"));
        labelNumber1->setMinimumSize(QSize(24, 24));
        labelNumber1->setMaximumSize(QSize(16777215, 24));
        labelNumber1->setAlignment(Qt::AlignCenter);

        horizontalLayout_1->addWidget(labelNumber1, 0, Qt::AlignTop);

        verticalLayout_61 = new QVBoxLayout();
        verticalLayout_61->setObjectName(QStringLiteral("verticalLayout_61"));
        verticalLayout_61->setContentsMargins(20, -1, 20, -1);
        labelSubtitle1 = new QLabel(widgetFaq1);
        labelSubtitle1->setObjectName(QStringLiteral("labelSubtitle1"));
        labelSubtitle1->setWordWrap(true);

        verticalLayout_61->addWidget(labelSubtitle1);

        verticalSpacer_10 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_61->addItem(verticalSpacer_10);

        labelContent1 = new QLabel(widgetFaq1);
        labelContent1->setObjectName(QStringLiteral("labelContent1"));
        labelContent1->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent1->setWordWrap(true);

        verticalLayout_61->addWidget(labelContent1);

        verticalSpacer_11 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_61->addItem(verticalSpacer_11);


        horizontalLayout_1->addLayout(verticalLayout_61);

        horizontalLayout_1->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq1);

        widgetFaq2 = new QWidget(scrollAreaWidgetContents);
        widgetFaq2->setObjectName(QStringLiteral("widgetFaq2"));
        horizontalPage2 = new QHBoxLayout(widgetFaq2);
        horizontalPage2->setObjectName(QStringLiteral("horizontalPage2"));
        labelNumber2 = new QLabel(widgetFaq2);
        labelNumber2->setObjectName(QStringLiteral("labelNumber2"));
        labelNumber2->setMinimumSize(QSize(24, 24));
        labelNumber2->setMaximumSize(QSize(16777215, 24));
        labelNumber2->setAlignment(Qt::AlignCenter);

        horizontalPage2->addWidget(labelNumber2, 0, Qt::AlignTop);

        verticalLayoutPage2 = new QVBoxLayout();
        verticalLayoutPage2->setSpacing(0);
        verticalLayoutPage2->setObjectName(QStringLiteral("verticalLayoutPage2"));
        verticalLayoutPage2->setContentsMargins(20, -1, 20, -1);
        labelSubtitle2 = new QLabel(widgetFaq2);
        labelSubtitle2->setObjectName(QStringLiteral("labelSubtitle2"));
        labelSubtitle2->setWordWrap(true);

        verticalLayoutPage2->addWidget(labelSubtitle2);

        verticalSpacer_20 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutPage2->addItem(verticalSpacer_20);

        labelContent2 = new QLabel(widgetFaq2);
        labelContent2->setObjectName(QStringLiteral("labelContent2"));
        labelContent2->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent2->setWordWrap(true);

        verticalLayoutPage2->addWidget(labelContent2);

        verticalSpacer_21 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutPage2->addItem(verticalSpacer_21);


        horizontalPage2->addLayout(verticalLayoutPage2);

        horizontalPage2->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq2);

        widgetFaq3 = new QWidget(scrollAreaWidgetContents);
        widgetFaq3->setObjectName(QStringLiteral("widgetFaq3"));
        horizontalpage_3 = new QHBoxLayout(widgetFaq3);
        horizontalpage_3->setObjectName(QStringLiteral("horizontalpage_3"));
        labelNumber3 = new QLabel(widgetFaq3);
        labelNumber3->setObjectName(QStringLiteral("labelNumber3"));
        labelNumber3->setMinimumSize(QSize(24, 24));
        labelNumber3->setMaximumSize(QSize(16777215, 24));
        labelNumber3->setAlignment(Qt::AlignCenter);

        horizontalpage_3->addWidget(labelNumber3, 0, Qt::AlignTop);

        verticalLayoutpage_3 = new QVBoxLayout();
        verticalLayoutpage_3->setObjectName(QStringLiteral("verticalLayoutpage_3"));
        verticalLayoutpage_3->setContentsMargins(20, -1, 20, -1);
        labelSubtitle3 = new QLabel(widgetFaq3);
        labelSubtitle3->setObjectName(QStringLiteral("labelSubtitle3"));
        labelSubtitle3->setWordWrap(true);

        verticalLayoutpage_3->addWidget(labelSubtitle3);

        verticalSpacer_30 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutpage_3->addItem(verticalSpacer_30);

        labelContent3 = new QLabel(widgetFaq3);
        labelContent3->setObjectName(QStringLiteral("labelContent3"));
        labelContent3->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent3->setWordWrap(true);

        verticalLayoutpage_3->addWidget(labelContent3);

        verticalSpacer_31 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutpage_3->addItem(verticalSpacer_31);


        horizontalpage_3->addLayout(verticalLayoutpage_3);

        horizontalpage_3->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq3);

        widgetFaq4 = new QWidget(scrollAreaWidgetContents);
        widgetFaq4->setObjectName(QStringLiteral("widgetFaq4"));
        horizontalPage_4 = new QHBoxLayout(widgetFaq4);
        horizontalPage_4->setObjectName(QStringLiteral("horizontalPage_4"));
        labelNumber4 = new QLabel(widgetFaq4);
        labelNumber4->setObjectName(QStringLiteral("labelNumber4"));
        labelNumber4->setMinimumSize(QSize(24, 24));
        labelNumber4->setMaximumSize(QSize(16777215, 24));
        labelNumber4->setAlignment(Qt::AlignCenter);

        horizontalPage_4->addWidget(labelNumber4, 0, Qt::AlignTop);

        verticalLayoutPage_4 = new QVBoxLayout();
        verticalLayoutPage_4->setObjectName(QStringLiteral("verticalLayoutPage_4"));
        verticalLayoutPage_4->setContentsMargins(20, -1, 20, -1);
        labelSubtitle4 = new QLabel(widgetFaq4);
        labelSubtitle4->setObjectName(QStringLiteral("labelSubtitle4"));
        labelSubtitle4->setWordWrap(true);

        verticalLayoutPage_4->addWidget(labelSubtitle4);

        verticalSpacer_40 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutPage_4->addItem(verticalSpacer_40);

        labelContent4 = new QLabel(widgetFaq4);
        labelContent4->setObjectName(QStringLiteral("labelContent4"));
        labelContent4->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent4->setWordWrap(true);

        verticalLayoutPage_4->addWidget(labelContent4);

        verticalSpacer_41 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutPage_4->addItem(verticalSpacer_41);


        horizontalPage_4->addLayout(verticalLayoutPage_4);

        horizontalPage_4->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq4);

        widgetFaq5 = new QWidget(scrollAreaWidgetContents);
        widgetFaq5->setObjectName(QStringLiteral("widgetFaq5"));
        horizontalPage_5 = new QHBoxLayout(widgetFaq5);
        horizontalPage_5->setObjectName(QStringLiteral("horizontalPage_5"));
        labelNumber5 = new QLabel(widgetFaq5);
        labelNumber5->setObjectName(QStringLiteral("labelNumber5"));
        labelNumber5->setMinimumSize(QSize(24, 24));
        labelNumber5->setMaximumSize(QSize(16777215, 24));
        labelNumber5->setAlignment(Qt::AlignCenter);

        horizontalPage_5->addWidget(labelNumber5, 0, Qt::AlignTop);

        verticalLayoutPage_5 = new QVBoxLayout();
        verticalLayoutPage_5->setObjectName(QStringLiteral("verticalLayoutPage_5"));
        verticalLayoutPage_5->setContentsMargins(20, -1, 20, -1);
        labelSubtitle5 = new QLabel(widgetFaq5);
        labelSubtitle5->setObjectName(QStringLiteral("labelSubtitle5"));
        labelSubtitle5->setWordWrap(true);

        verticalLayoutPage_5->addWidget(labelSubtitle5);

        verticalSpacer_50 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutPage_5->addItem(verticalSpacer_50);

        labelContent5 = new QLabel(widgetFaq5);
        labelContent5->setObjectName(QStringLiteral("labelContent5"));
        labelContent5->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent5->setWordWrap(true);

        verticalLayoutPage_5->addWidget(labelContent5);

        verticalSpacer_51 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutPage_5->addItem(verticalSpacer_51);


        horizontalPage_5->addLayout(verticalLayoutPage_5);

        horizontalPage_5->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq5);

        widgetFaq6 = new QWidget(scrollAreaWidgetContents);
        widgetFaq6->setObjectName(QStringLiteral("widgetFaq6"));
        horizontalpage_6 = new QHBoxLayout(widgetFaq6);
        horizontalpage_6->setObjectName(QStringLiteral("horizontalpage_6"));
        labelNumber6 = new QLabel(widgetFaq6);
        labelNumber6->setObjectName(QStringLiteral("labelNumber6"));
        labelNumber6->setMinimumSize(QSize(24, 24));
        labelNumber6->setMaximumSize(QSize(16777215, 24));
        labelNumber6->setAlignment(Qt::AlignCenter);

        horizontalpage_6->addWidget(labelNumber6, 0, Qt::AlignTop);

        verticalLayoutpage_6 = new QVBoxLayout();
        verticalLayoutpage_6->setSpacing(0);
        verticalLayoutpage_6->setObjectName(QStringLiteral("verticalLayoutpage_6"));
        verticalLayoutpage_6->setContentsMargins(20, -1, 20, -1);
        labelSubtitle6 = new QLabel(widgetFaq6);
        labelSubtitle6->setObjectName(QStringLiteral("labelSubtitle6"));
        labelSubtitle6->setWordWrap(true);

        verticalLayoutpage_6->addWidget(labelSubtitle6);

        verticalSpacer_60 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutpage_6->addItem(verticalSpacer_60);

        labelContent6 = new QLabel(widgetFaq6);
        labelContent6->setObjectName(QStringLiteral("labelContent6"));
        labelContent6->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent6->setWordWrap(true);

        verticalLayoutpage_6->addWidget(labelContent6);

        verticalSpacer_61 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutpage_6->addItem(verticalSpacer_61);


        horizontalpage_6->addLayout(verticalLayoutpage_6);

        horizontalpage_6->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq6);

        widgetFaq7 = new QWidget(scrollAreaWidgetContents);
        widgetFaq7->setObjectName(QStringLiteral("widgetFaq7"));
        horizontalpage_7 = new QHBoxLayout(widgetFaq7);
        horizontalpage_7->setObjectName(QStringLiteral("horizontalpage_7"));
        labelNumber7 = new QLabel(widgetFaq7);
        labelNumber7->setObjectName(QStringLiteral("labelNumber7"));
        labelNumber7->setMinimumSize(QSize(24, 24));
        labelNumber7->setMaximumSize(QSize(16777215, 24));
        labelNumber7->setAlignment(Qt::AlignCenter);

        horizontalpage_7->addWidget(labelNumber7, 0, Qt::AlignTop);

        verticalLayoutpage_7 = new QVBoxLayout();
        verticalLayoutpage_7->setObjectName(QStringLiteral("verticalLayoutpage_7"));
        verticalLayoutpage_7->setContentsMargins(20, -1, 20, -1);
        labelSubtitle7 = new QLabel(widgetFaq7);
        labelSubtitle7->setObjectName(QStringLiteral("labelSubtitle7"));
        labelSubtitle7->setWordWrap(true);

        verticalLayoutpage_7->addWidget(labelSubtitle7);

        verticalSpacer_70 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutpage_7->addItem(verticalSpacer_70);

        labelContent7 = new QLabel(widgetFaq7);
        labelContent7->setObjectName(QStringLiteral("labelContent7"));
        labelContent7->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent7->setWordWrap(true);

        verticalLayoutpage_7->addWidget(labelContent7);

        verticalSpacer_71 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutpage_7->addItem(verticalSpacer_71);


        horizontalpage_7->addLayout(verticalLayoutpage_7);

        horizontalpage_7->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq7);

        widgetFaq8 = new QWidget(scrollAreaWidgetContents);
        widgetFaq8->setObjectName(QStringLiteral("widgetFaq8"));
        horizontalpage_8 = new QHBoxLayout(widgetFaq8);
        horizontalpage_8->setObjectName(QStringLiteral("horizontalpage_8"));
        labelNumber8 = new QLabel(widgetFaq8);
        labelNumber8->setObjectName(QStringLiteral("labelNumber8"));
        labelNumber8->setMinimumSize(QSize(24, 24));
        labelNumber8->setMaximumSize(QSize(16777215, 24));
        labelNumber8->setAlignment(Qt::AlignCenter);

        horizontalpage_8->addWidget(labelNumber8, 0, Qt::AlignTop);

        verticalLayoutpage_8 = new QVBoxLayout();
        verticalLayoutpage_8->setObjectName(QStringLiteral("verticalLayoutpage_8"));
        verticalLayoutpage_8->setContentsMargins(20, -1, 20, -1);
        labelSubtitle8 = new QLabel(widgetFaq8);
        labelSubtitle8->setObjectName(QStringLiteral("labelSubtitle8"));
        labelSubtitle8->setWordWrap(true);

        verticalLayoutpage_8->addWidget(labelSubtitle8);

        verticalSpacer_80 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutpage_8->addItem(verticalSpacer_80);

        labelContent8 = new QLabel(widgetFaq8);
        labelContent8->setObjectName(QStringLiteral("labelContent8"));
        labelContent8->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent8->setWordWrap(true);

        verticalLayoutpage_8->addWidget(labelContent8);

        verticalSpacer_81 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutpage_8->addItem(verticalSpacer_81);


        horizontalpage_8->addLayout(verticalLayoutpage_8);

        horizontalpage_8->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq8);

        widgetFaq9 = new QWidget(scrollAreaWidgetContents);
        widgetFaq9->setObjectName(QStringLiteral("widgetFaq9"));
        horizontalpage_9 = new QHBoxLayout(widgetFaq9);
        horizontalpage_9->setObjectName(QStringLiteral("horizontalpage_9"));
        labelNumber9 = new QLabel(widgetFaq9);
        labelNumber9->setObjectName(QStringLiteral("labelNumber9"));
        labelNumber9->setMinimumSize(QSize(24, 24));
        labelNumber9->setMaximumSize(QSize(16777215, 24));
        labelNumber9->setAlignment(Qt::AlignCenter);

        horizontalpage_9->addWidget(labelNumber9, 0, Qt::AlignTop);

        verticalLayoutpage_9 = new QVBoxLayout();
        verticalLayoutpage_9->setObjectName(QStringLiteral("verticalLayoutpage_9"));
        verticalLayoutpage_9->setContentsMargins(20, -1, 20, -1);
        labelSubtitle9 = new QLabel(widgetFaq9);
        labelSubtitle9->setObjectName(QStringLiteral("labelSubtitle9"));
        labelSubtitle9->setWordWrap(true);

        verticalLayoutpage_9->addWidget(labelSubtitle9);

        verticalSpacer_90 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutpage_9->addItem(verticalSpacer_90);

        labelContent9 = new QLabel(widgetFaq9);
        labelContent9->setObjectName(QStringLiteral("labelContent9"));
        labelContent9->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent9->setWordWrap(true);

        verticalLayoutpage_9->addWidget(labelContent9);

        verticalSpacer_91 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutpage_9->addItem(verticalSpacer_91);


        horizontalpage_9->addLayout(verticalLayoutpage_9);

        horizontalpage_9->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq9);

        widgetFaq10 = new QWidget(scrollAreaWidgetContents);
        widgetFaq10->setObjectName(QStringLiteral("widgetFaq10"));
        horizontalpage_10 = new QHBoxLayout(widgetFaq10);
        horizontalpage_10->setObjectName(QStringLiteral("horizontalpage_10"));
        labelNumber10 = new QLabel(widgetFaq10);
        labelNumber10->setObjectName(QStringLiteral("labelNumber10"));
        labelNumber10->setMinimumSize(QSize(24, 24));
        labelNumber10->setMaximumSize(QSize(16777215, 24));
        labelNumber10->setAlignment(Qt::AlignCenter);

        horizontalpage_10->addWidget(labelNumber10, 0, Qt::AlignTop);

        verticalLayoutpage_10 = new QVBoxLayout();
        verticalLayoutpage_10->setObjectName(QStringLiteral("verticalLayoutpage_10"));
        verticalLayoutpage_10->setContentsMargins(20, -1, 20, -1);
        labelSubtitle10 = new QLabel(widgetFaq10);
        labelSubtitle10->setObjectName(QStringLiteral("labelSubtitle10"));
        labelSubtitle10->setWordWrap(true);

        verticalLayoutpage_10->addWidget(labelSubtitle10);

        verticalSpacer_100 = new QSpacerItem(20, 30, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayoutpage_10->addItem(verticalSpacer_100);

        labelContent10 = new QLabel(widgetFaq10);
        labelContent10->setObjectName(QStringLiteral("labelContent10"));
        labelContent10->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        labelContent10->setWordWrap(true);

        verticalLayoutpage_10->addWidget(labelContent10);

        verticalSpacer_92 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutpage_10->addItem(verticalSpacer_92);


        horizontalpage_10->addLayout(verticalLayoutpage_10);

        horizontalpage_10->setStretch(1, 1);

        verticalLayout_7->addWidget(widgetFaq10);

        scrollAreaFaq->setWidget(scrollAreaWidgetContents);

        verticalLayout_6->addWidget(scrollAreaFaq);


        verticalLayout_5->addLayout(verticalLayout_6);


        horizontalLayout_6->addWidget(right);

        horizontalLayout_6->setStretch(0, 2);
        horizontalLayout_6->setStretch(2, 3);

        verticalLayoutcont->addLayout(horizontalLayout_6);


        horizontalLayout->addWidget(container);


        retranslateUi(SettingsFaqWidget);

        QMetaObject::connectSlotsByName(SettingsFaqWidget);
    } // setupUi

    void retranslateUi(QWidget *SettingsFaqWidget)
    {
        SettingsFaqWidget->setWindowTitle(QApplication::translate("SettingsFaqWidget", "Form", Q_NULLPTR));
        labelTitle->setText(QApplication::translate("SettingsFaqWidget", "TextLabel", Q_NULLPTR));
        pushButtonExit->setText(QApplication::translate("SettingsFaqWidget", "PushButton", Q_NULLPTR));
        groupBox->setTitle(QString());
        pushButtonFaq1->setText(QApplication::translate("SettingsFaqWidget", "1) What is allt?", Q_NULLPTR));
        pushButtonFaq2->setText(QApplication::translate("SettingsFaqWidget", "2) Why are my allt unspendable?", Q_NULLPTR));
        pushButtonFaq3->setText(QApplication::translate("SettingsFaqWidget", "3) allt privacy? What is Zerocoin (zallt)?", Q_NULLPTR));
        pushButtonFaq4->setText(QApplication::translate("SettingsFaqWidget", "4) Why are my zallt unspendable?", Q_NULLPTR));
        pushButtonFaq5->setText(QApplication::translate("SettingsFaqWidget", "5) Why did my wallet convert the balance\n"
"    into zallt automatically?", Q_NULLPTR));
        pushButtonFaq6->setText(QApplication::translate("SettingsFaqWidget", "6) How do I receive allt/zallt?", Q_NULLPTR));
        pushButtonFaq7->setText(QApplication::translate("SettingsFaqWidget", "7) How do I stake allt/zallt?", Q_NULLPTR));
        pushButtonFaq8->setText(QApplication::translate("SettingsFaqWidget", "8) Where I should go if I need support?", Q_NULLPTR));
        pushButtonFaq9->setText(QApplication::translate("SettingsFaqWidget", "9) What is a Master Node?", Q_NULLPTR));
        pushButtonFaq10->setText(QApplication::translate("SettingsFaqWidget", "10) What is a Master Node Controller?", Q_NULLPTR));
        labelWebLink->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                    You can read more here <a style='color: #f13845' href='http://allt.org'>\n"
"                    http://allt.org.\n"
"                  ", Q_NULLPTR));
        pushButtonWebLink->setText(QApplication::translate("SettingsFaqWidget", "PushButton", Q_NULLPTR));
        labelNumber1->setText(QApplication::translate("SettingsFaqWidget", "1", Q_NULLPTR));
        labelSubtitle1->setText(QApplication::translate("SettingsFaqWidget", "What is allt?", Q_NULLPTR));
        labelContent1->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           allt is a form of digital online money using blockchain technology\n"
"                           that can be easily transferred globally, instantly, and with near\n"
"                           zero fees.\n"
"                           </p><p align=\"justify\">\n"
"                           allt utilizes a Proof of Stake (PoS) consensus system algorithm,\n"
"                           allowing all owners of allt to participate in earning block rewards\n"
"                           while securing the network with full node wallets, as well as to\n"
"                           run Masternodes to create and vote on proposals.\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber2->setText(QApplication::translate("SettingsFaqWidget", "2", Q_NULLPTR));
        labelSubtitle2->setText(QApplication::translate("SettingsFaqWidget", "Why are my allt unspendable?", Q_NULLPTR));
        labelContent2->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           Newly received allt requires 6 confirmations on the network\n"
"                           to become eligible for spending which can take ~6 minutes.\n"
"                           </p><p align=\"justify\">\n"
"                           Your allt wallet also needs to be completely synchronized\n"
"                           to see and spend balances on the network.\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber3->setText(QApplication::translate("SettingsFaqWidget", "3", Q_NULLPTR));
        labelSubtitle3->setText(QApplication::translate("SettingsFaqWidget", "allt privacy? What is Zerocoin (zallt)?", Q_NULLPTR));
        labelContent3->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           zallt is an optional privacy-centric method of coin mixing on the\n"
"                           allt blockchain. Basically all your transactions cannot be tracked\n"
"                           on to any block explorer. You can read more about the technicals in the\n"
"                           <a style='color: #f13845' href='https://allt.org/zallt/'>\n"
"                           \"allt Zerocoin (zallt) Technical Paper\"</a>.\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber4->setText(QApplication::translate("SettingsFaqWidget", "4", Q_NULLPTR));
        labelSubtitle4->setText(QApplication::translate("SettingsFaqWidget", "Why are my zallt unspendable?", Q_NULLPTR));
        labelContent4->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           After minting, zallt will require 20 confirmations as well as 1\n"
"                           additional mint of the same denomination on the network to\n"
"                           become eligible for spending.\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber5->setText(QApplication::translate("SettingsFaqWidget", "5", Q_NULLPTR));
        labelSubtitle5->setText(QApplication::translate("SettingsFaqWidget", "Why did my wallet convert the balance into zallt automatically?", Q_NULLPTR));
        labelContent5->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           By default the allt wallet will convert 10% of your entire allt\n"
"                           balance to zallt to assist the network. If you do not wish to\n"
"                           stake zallt or take advantage of the privacy benefit it brings,\n"
"                           you can disable the automatic minting in your allt wallet by\n"
"                           going to Settings->Options and deselecting \342\200\234Enable zallt Automint\342\200\235.\n"
"                           If you are not making use of the allt-QT or GUI you can simply open\n"
"                           your allt.conf file and add <i>enablezeromint=0</i> Without the quotation\n"
"                           marks and restart your wallet to disable automint.</p>\n"
"                           </p><p align=\"justify\">\n"
"                           You can read more about zallt in the\n"
"                           <a style='"
                        "color: #f13845' href='https://allt.org/zallt/'> \"allt Zerocoin (zallt) Technical Paper\"</a>.\n"
"                           If you would like to keep and stake your zallt, please read the \"How do I stake\"\n"
"                           section of the FAQ below.\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber6->setText(QApplication::translate("SettingsFaqWidget", "6", Q_NULLPTR));
        labelSubtitle6->setText(QApplication::translate("SettingsFaqWidget", "How do I receive allt/zallt?", Q_NULLPTR));
        labelContent6->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           zallt can be spent and sent to any allt address. The receiver will\n"
"                           receive standard allt but the origin of the allt is anonymized by the zallt Protocol.\n"
"                           </p><p align=\"justify\">\n"
"                           If you want more zallt you will need to mint your balance in the \342\200\234Privacy\342\200\235 tab.\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber7->setText(QApplication::translate("SettingsFaqWidget", "7", Q_NULLPTR));
        labelSubtitle7->setText(QApplication::translate("SettingsFaqWidget", "How do I stake allt/zallt?", Q_NULLPTR));
        labelContent7->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           To Stake allt:\n"
"                           </p><p align=\"justify\">\n"
"                           <ol><li>\n"
"                           Make sure your wallet is completely synchronized and you are using the latest release.\n"
"                           <li>\n"
"                           You must have a balance of allt with a minimum of 101 confirmations.\n"
"                           <li>\n"
"                           Your wallet must stay online and be unlocked for anonymization and staking purposes.\n"
"                           <li>\n"
"                           Once all those steps are followed staking should be enabled.\n"
"                           <li>\n"
"                           You can see the status of staking in the wallet by mousing over the package icon in the row on the top left of the wallet interface. There package will be lit up and will state \"Staking Enabled\" to indicate"
                        " it is staking.  Using the command line interface (allt-cli); the command <i>getstakingstatus</i> will confirm that staking is active.\n"
"                           </li></ol>\n"
"                           </p><p align=\"justify\">\n"
"                           To Stake zallt:\n"
"                           </p><p align=\"justify\">\n"
"                           <ol><li>\n"
"                           Make sure your wallet is completely synchronized and you are using the latest release.\n"
"                           <li>\n"
"                           Your newly minted or existing zallt balance must have a minimum of 200 confirmations.\n"
"                           <li>\n"
"                           Your wallet must stay online and be unlocked for anonymization and staking purposes.\n"
"                           Staking should now be enabled.\n"
"                           </li></ol>\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber8->setText(QApplication::translate("SettingsFaqWidget", "8", Q_NULLPTR));
        labelSubtitle8->setText(QApplication::translate("SettingsFaqWidget", "Where I should go if I need support?", Q_NULLPTR));
        labelContent8->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           We have support channels in most of our official chat groups, for support please reach out to us via\n"
"                           <a style='color: #f13845' href='https://discord.gg/QDMkgW3'>\n"
"                           Discord</a> or at\n"
"                           <a style='color: #f13845' href='mailto://info@allt.org'>\n"
"                           info@allt.org.\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber9->setText(QApplication::translate("SettingsFaqWidget", "9", Q_NULLPTR));
        labelSubtitle9->setText(QApplication::translate("SettingsFaqWidget", "What is a Master Node?", Q_NULLPTR));
        labelContent9->setText(QApplication::translate("SettingsFaqWidget", "\n"
"                           <html><head/><body><p align=\"justify\">\n"
"                           A masternode is a computer running a full node allt Coin wallet with a\n"
"                           requirement of current secured collateral to provide extra services\n"
"                           to the network and in return, receive a portion of the block reward\n"
"                           regularly.  These services include:\n"
"                           </p><p align=\"justify\">\n"
"\n"
"                           <ul>\n"
"                           <li>Instant transactions (SwiftX)</li>\n"
"                           <li>A decentralized governance (Proposal Voting)</li>\n"
"                           <li>A decentralized budgeting system (Treasury)</li>\n"
"                           <li>Validation of transactions within each block</li>\n"
"                           <li>Act as an additional full node in the network</li>\n"
"                           </ul>\n"
"\n"
"                           </p>"
                        "<p align=\"justify\">\n"
"                           For providing such services, masternodes are also paid a certain portion\n"
"                           of reward for each block. This can serve as a passive income to the\n"
"                           masternode owners minus their running cost.\n"
"                           </p><p align=\"justify\">\n"
"\n"
"                           Masternode Perks:\n"
"                           </p><p align=\"justify\">\n"
"                           <ul>\n"
"                           <li>Participate in allt Governance</li>\n"
"                           <li>Earn Masternode Rewards</li>\n"
"                           <li>Commodity option for future sale</li>\n"
"                           <li>Help secure the allt network</li>\n"
"                           </ul>\n"
"                           </p><p align=\"justify\">\n"
"\n"
"                           Requirements:\n"
"                           </p><p align=\"justify\">\n"
"                           <ul>\n"
"   "
                        "                        <li>Current Collateral per single Masternode instance</li>\n"
"                           <li>Must be stored in a core wallet</li>\n"
"                           <li>Need dedicated IP address</li>\n"
"                           <li>Masternode wallet to remain online</li>\n"
"                           </ul>\n"
"                           </p></body></html>\n"
"                         ", Q_NULLPTR));
        labelNumber10->setText(QApplication::translate("SettingsFaqWidget", "10", Q_NULLPTR));
        labelSubtitle10->setText(QApplication::translate("SettingsFaqWidget", "What is a Master Node Controller?", Q_NULLPTR));
        labelContent10->setText(QApplication::translate("SettingsFaqWidget", "<html><head/><body><p align=\"justify\">A Masternode Controller wallet is where the current collateral can reside during a Controller-Remote masternode setup. It is a wallet that can activate the remote masternode wallet/s and allows you to keep your collateral coins offline while the remote masternode remains online. </p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class SettingsFaqWidget: public Ui_SettingsFaqWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGSFAQWIDGET_H
